# WP Modification History
WordPress Modification History adds a metabox that shows modification history on a particular set of post types.

## Requires

- PHP 5.3+

## Install it

Drop unzipped folder into wp-content/plugins/wp-mod-history and activate the plugin via the plugins admin page.

Alternatively, just install the plugin from the plugins admin page by searching for "WP Modification History"